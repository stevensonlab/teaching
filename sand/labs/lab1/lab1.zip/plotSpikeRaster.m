

% plot spike raster...

for i=1:length(data(1).spks)
	???
end
