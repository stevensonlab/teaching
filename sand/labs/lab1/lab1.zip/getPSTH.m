
% calculate psth...

binsize = 5;
maxTime = 2000;

psth = ???;
c = 1;
for i=1:length(data(1).spks)
	for j=1:binsize:maxTime
		psth(c) =???
		c = c+1;
	end
end
